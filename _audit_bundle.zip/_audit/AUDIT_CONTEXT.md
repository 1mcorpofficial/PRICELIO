# AUDIT_CONTEXT

## Repo
- Name: Pricelio
- Root: /home/mcorpofficial/projektai/Pricelio
- Git: not a git repository (no branch/commits available)
- Audit date (local): 2026-01-22

## High-level structure
- apps/
  - admin/ (Node app with server.js, db.js, public/index.html, .env)
  - web/ (README only)
- services/ (each has package.json + src)
  - api, receipts, ingest, analytics, ai-gateway
- infra/
  - docker-compose.yml, .env, .env.example, postgres init SQL
- db/
  - migrations + schema.sql + seeds
- static HTML UIs at repo root (alerts-ui.html, basket-planner.html, etc.)

## Detected config / key files
- Docker compose: infra/docker-compose.yml
- Env files present (paths only):
- ./apps/admin/.env
- ./infra/.env
- ./infra/.env.example
- ./services/ai-gateway/.env
- ./services/ai-gateway/.env.example
- ./services/analytics/.env
- ./services/api/.env
- ./services/api/.env.example
- ./services/ingest/.env
- ./services/receipts/.env
- ./services/receipts/.env.example

## Docker compose services & ports (from infra/docker-compose.yml / config --no-interpolate)
- postgres: 5432:5432 (default port via ${POSTGRES_PORT:-5432})
- redis: 6379:6379 (default port via ${REDIS_PORT:-6379})
- minio: 9000:9000 + 9001:9001 (default ports via env fallbacks)
- rabbitmq: 5672:5672 + 15672:15672 (default ports via env fallbacks)

## Runtime state (local host)
- docker compose ps: no services listed (no active compose in repo root)
- Listening ports observed (non-exhaustive): 27017, 27018, 5432, 5000, 5900, 3389, 631, DNS (53), plus various localhost-only ports tied to the editor process

## Tests
- Root npm test: not run (no package.json in repo root)

## Risks / findings
- Weak/default credentials detected in docs/scripts/configs (redacted in logs). Seen in files such as:
  - FINAL_REPORTS/09_SETUP_AND_DEPLOYMENT.md
  - ENV_TEMPLATES.md
  - SETUP_GUIDE.md
  - setup-*.sh
  - infra/docker-compose.yml
  - services/*/.env and apps/admin/.env
- Hardcoded admin credential logic in apps/admin (server.js and public/index.html). Values redacted.
- Multiple .env files exist in repo tree (contents not shown); ensure they are not committed or leaked.
- Docker compose config warns that the `version` field is obsolete (warning from docker compose config).
- No automated test results available.

## Potential production blockers (top 10)
1) Not a git repository: no commit history/branching for traceability.
2) Weak/default credentials referenced in docs/scripts/configs.
3) Hardcoded admin auth logic in apps/admin (server/client).
4) Secrets stored in .env files under services/apps/infra (risk if committed/distributed).
5) No verified test run at repo root (no package.json).
6) Compose config warning: obsolete `version` field in infra/docker-compose.yml.
7) Unknown runtime state for services (docker compose not running in repo root).
8) No evidence of CI/CD or test automation in repo root.
9) Potential environment mismatch: multiple service-specific .env files with unknown completeness.
10) Security posture unclear (auth, rate limits, audit logging) without running services or tests.
